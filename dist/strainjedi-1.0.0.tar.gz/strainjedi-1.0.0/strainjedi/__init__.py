"""
strainjedi.

The JEDI analysis python library.
"""

__version__ = "1.0.0"
__author__ = 'Tim Neudecker, Sanna Benter, Henry Wang, Wilke Dononelli'
__credits__ = 'Neudecker Group'